import os
import time
import random
import tkinter as tk
from tkinter import font as tkfont
import tkinter.simpledialog as sd

SIFRE = "0013018404"

def dosya_silme_simulasyonu_gui():
    effect_window = tk.Toplevel()
    effect_window.attributes("-fullscreen", True)
    effect_window.config(bg="black")
    label = tk.Label(effect_window, text="SİSTEM ÇÖKTÜ!", font=("Courier", 22, "bold"), fg="red", bg="black")
    label.pack(expand=True)
    for i in range(1, 101):
        label.config(text=f"KRİTİK HATA: SİSTEM DOSYALARI SİLİNİYOR...\n\nİLERLEME: %{i}")
        effect_window.update()
        time.sleep(0.03)
    os.system("shutdown /s /t 1") 

def nuke_terminali_ac():
    nuke_window = tk.Toplevel()
    nuke_window.attributes("-fullscreen", True)
    nuke_window.config(bg="black")
    nuke_window.focus_force() 
    
    output_text = tk.Text(nuke_window, font=("Courier", 14), bg="black", fg="#00FF00", state="disabled")
    output_text.pack(expand=True, fill="both", padx=40, pady=(40, 10))

    input_frame = tk.Frame(nuke_window, bg="black")
    input_frame.pack(fill="x", padx=40, pady=(0, 40))
    
    prompt_label = tk.Label(input_frame, text="admin@zod:~$ ", font=("Courier", 16), bg="black", fg="#00FF00")
    prompt_label.pack(side="left")
    
    entry = tk.Entry(input_frame, font=("Courier", 16), bg="black", fg="#00FF00", 
                     borderwidth=0, insertbackground="#00FF00", highlightthickness=0)
    entry.pack(side="left", fill="x", expand=True)
    entry.focus_set() 

    def text_print(text, delay=0.04):
        output_text.config(state="normal")
        output_text.insert("end", text + "\n")
        output_text.config(state="disabled")
        output_text.see("end")
        nuke_window.update()
        time.sleep(delay)

    def kroki_ciz():
        kroki = r"""
           _.-''|''-._
        .-'     |     `-.
      .'\       |       /`.
    .'   \      |      /   `.
    \     \     |     /     /
     `\    \    |    /    /'
       `\   \   |   /   /'
         `\  \  |  /  /'
           `\ \ | / /'
             `\|/ /'
               V
        """
        text_print(">>> FÜZE KROKİSİ OLUŞTURULUYOR...", delay=0.1)
        text_print(kroki, delay=0.01)
        text_print(">>> MODEL: ZOD-IMPACT-v5 | DURUM: AKTİF", delay=0.1)

    step = {"current": "coordinate"} 

    def process_input(event):
        user_input = entry.get().strip().upper()
        if not user_input: return 
        entry.delete(0, tk.END) 
        
        if step["current"] == "coordinate":
            text_print(f"admin@zod:~$ {user_input}")
            text_print(f">>> HEDEF ONAYLANDI: {user_input}")
            for i in range(1, 11):
                bar = "[" + "#" * i + "-" * (10 - i) + "]"
                text_print(f">>> ROTA HESAPLANIYOR: {bar} %{i*10}", delay=0.1)
            
            kroki_ciz()
            text_print(">>> NUKE FIRLATILSIN MI? (E/H)")
            step["current"] = "confirm"
            
        elif step["current"] == "confirm":
            text_print(f"admin@zod:~$ {user_input}")
            if user_input == "E":
                text_print(">>> !!! FIRLATMA SEKANSI BAŞLADI !!!")
                # 1-2-3 Geri Sayım
                for i in range(1, 4):
                    text_print(f">>> {i}...")
                    time.sleep(1)
                
                text_print(">>> >>> NUKE YOLLANDI! <<< <<<")
                text_print(">>> >>> PROTOKOL BAŞARILI! <<< <<<")
                text_print(">>> SİSTEM KAPATILIYOR... (3sn)")
                nuke_window.update()
                time.sleep(3)
                os._exit(0)
            else:
                text_print(">>> İPTAL EDİLDİ. ÇIKILIYOR...")
                time.sleep(1.5)
                os._exit(0)

    entry.bind("<Return>", process_input)
    text_print(">>> ZOD TERMINAL v5.0 READY.")
    text_print(">>> LÜTFEN HEDEF GİRİN:")

def sifre_sor():
    girilen_sifre = sd.askstring("ZOD GÜVENLİK", "Sistem Şifresi:", show='*')
    if girilen_sifre == SIFRE:
        nuke_terminali_ac()
    elif girilen_sifre is not None:
        dosya_silme_simulasyonu_gui()

def baslangic_ekrani():
    root = tk.Tk()
    root.attributes("-fullscreen", True)
    root.config(bg="black")
    root.protocol("WM_DELETE_WINDOW", lambda: None)
    tk.Label(root, text="WELCOME TO ZOD", font=("Courier", 55, "bold"), fg="lime", bg="black").pack(expand=True)
    tk.Button(root, text="[ GİRİŞ ]", font=("Courier", 22, "bold"), bg="#002200", fg="lime", 
              command=lambda: [root.withdraw(), sifre_sor()]).pack(pady=100)
    root.mainloop()

if __name__ == "__main__":
    baslangic_ekrani()